 # upload the file customer

#p1-customers.xlsx - This dataset includes the following information on about 2,300 customers.

customer <- read_excel(file.choose())
View(customer)

mail_list<- read_excel(file.choose())
View(mail_list)

summary(customer)

scatterplotMatrix(~Avg_Num_Products_Purchased+Avg_Sale_Amount+Customer_ID+Store_Number+X._Years_as_Customer+ZIP,
                  regLine=FALSE, smooth=FALSE, diagonal=list(method="oned"), data=customer)

ggplot(customer,aes(Avg_Num_Products_Purchased,Avg_Sale_Amount))+geom_point()

ggplot(customer, aes(Customer_Segment,Avg_Sale_Amount))+geom_point()

linear_model <- lm(formula = Avg_Sale_Amount ~ Avg_Num_Products_Purchased + Customer_Segment,data = customer)
scatterplot(Avg_Sale_Amount~Avg_Num_Products_Purchased, regLine=FALSE, smooth=FALSE, boxplots='xy', data=customer)

